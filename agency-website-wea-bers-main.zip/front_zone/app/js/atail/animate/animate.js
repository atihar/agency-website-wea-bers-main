class Animate {
  constructor() {

  }

  init() {

  }
}
