class AtailPromise {
  constructor() {
    return new Promise();
  }
}
